module.exports = {
    url:  'mongodb+srv://kayuronan29:ugAadDENH6nWwj3h@cluster0.sdkwaui.mongodb.net/?retryWrites=true&w=majority'
}